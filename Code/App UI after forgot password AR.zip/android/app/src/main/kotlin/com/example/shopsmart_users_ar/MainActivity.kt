package com.example.shopsmart_users_ar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
